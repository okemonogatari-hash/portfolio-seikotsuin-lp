# photo-album Windows向けメモ

このフォルダは、現場写真から写真帳Excelを作るためのClaude Codeスキルです。

## まずClaude Codeに言うこと

```text
この photo-album スキルを使って、まずサンプル写真で写真帳Excelを作ってください。
Windowsなので、必要なら py -3 を使ってください。
エラーが出たら自己修復して、最後に verify_album_xlsx.py で画像が埋め込まれているか確認してください。
```

## Windowsで手動確認するとき

PowerShellで `photo-album` フォルダに移動してから実行します。

```powershell
py -3 setup_check.py sample
py -3 build_album_xlsx.py
py -3 verify_album_xlsx.py
```

`py -3` が使えない場合は、次も試せます。

```powershell
python setup_check.py sample
python build_album_xlsx.py
python verify_album_xlsx.py
```

## できたファイル

- `写真帳_出力.xlsx`
  - Excelで開く写真帳です。
- `album_check_result.json`
  - Claude Codeが検証結果を読むためのファイルです。

## 黄色セルが出たら

黄色セルは「要確認」の印です。
写真が足りない、写真を開けない、命名ルールが合っていない場合に出ます。

## 写真ファイル名のルール

写真ファイル名の最後を、次のようにしてください。

- `0001S.JPG`
- `0002F.JPG`

半角数字4桁 + `S` または `F` が目印です。
