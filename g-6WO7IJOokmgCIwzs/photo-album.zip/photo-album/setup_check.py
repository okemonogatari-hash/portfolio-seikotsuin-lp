#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🩺 写真帳作成スキル — 環境ドクター（初回セットアップ診断）

このスクリプトは「写真帳を作る本番スクリプト」を動かす前に、
お使いのパソコンが準備OKかどうかを、やさしく1つずつ確認します。

使い方（ターミナルにそのまま貼り付けて Enter）:
    python3 setup_check.py
    python3 setup_check.py "/写真の入ったフォルダのパス"   ← 写真フォルダも一緒に見たいとき
    py -3 setup_check.py                                   ← Windowsの場合

AIに詳しくない方でも読めるよう、結果は「✅ だいじょうぶ／⚠️ ここだけ直そう」で出ます。
"""
import sys
import os
import re
import tempfile


def configure_output():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


configure_output()


# 結果をためておく入れ物（最後にまとめて表示）
ok_list = []      # ✅ 問題なかったもの
warn_list = []    # ⚠️ 注意（作成は進められるもの）
todo_list = []    # ⚠️ 直してほしいもの（直し方つき）

IMAGE_EXTS = (".jpg", ".jpeg", ".png")
PHOTO_NAME_RE = re.compile(r"(\d{4})([SF])\.(jpe?g|png)$", re.IGNORECASE)


def ok(msg):
    ok_list.append(msg)
    print(f"  ✅ {msg}")


def warn(msg, how=None):
    warn_list.append((msg, how))
    print(f"  ⚠️ {msg}")
    if how:
        print(f"      → 確認：{how}")


def todo(msg, how):
    todo_list.append((msg, how))
    print(f"  ⚠️ {msg}")
    print(f"      → 直し方：{how}")


def section(title):
    print("\n" + "─" * 52)
    print(f"  {title}")
    print("─" * 52)


def install_cmd(pip_name):
    exe = sys.executable or "python"
    if " " in exe and not (exe.startswith('"') and exe.endswith('"')):
        exe = f'"{exe}"'
    return f"{exe} -m pip install {pip_name}"


def check_python():
    section("① Python（パイソン）が使えるか")
    v = sys.version_info
    if v.major == 3 and v.minor >= 8:
        ok(f"Python {v.major}.{v.minor} が入っています")
    elif v.major == 3:
        todo(
            f"Python {v.major}.{v.minor} は少し古めです",
            "Python 3.10 以上を入れると安心です（Mac/WindowsどちらもOK）",
        )
    else:
        todo(
            f"Python {v.major}.{v.minor} は古すぎます",
            "https://www.python.org から最新版を入れてください",
        )


def check_library(import_name, pip_name, nice_name):
    """ライブラリが入っているか確認。無ければ pip install の一行を案内。"""
    try:
        __import__(import_name)
        ok(f"{nice_name} が入っています")
        return True
    except ImportError:
        todo(
            f"{nice_name} がまだ入っていません",
            f"ターミナル/PowerShellで次の1行を実行 →  {install_cmd(pip_name)}",
        )
        return False


def check_libraries():
    section("② 必要な部品（ライブラリ）がそろっているか")
    a = check_library("openpyxl", "openpyxl", "openpyxl（エクセルを作る部品）")
    b = check_library("PIL", "Pillow", "Pillow（画像をあつかう部品）")
    return a, b


def check_excel_write(can_openpyxl):
    section("③ エクセル（.xlsx）を作れるか（おためし1枚）")
    if not can_openpyxl:
        todo(
            "openpyxl が無いので、まだエクセルは作れません",
            "②の openpyxl を入れてから、もう一度この診断を走らせてください",
        )
        return
    try:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = "テスト"
        fd, tmp = tempfile.mkstemp(prefix="_album_test_", suffix=".xlsx")
        os.close(fd)
        try:
            wb.save(tmp)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        ok("エクセルファイルを作って消すテストに成功しました")
    except Exception as e:
        todo(
            f"エクセルの作成に失敗しました（{e}）",
            "パソコンの空き容量・書き込み権限を確認してください",
        )


def check_photo_folder(can_pillow):
    section("④ 写真フォルダが読めるか")
    if len(sys.argv) < 2:
        print("  （写真フォルダのパスが指定されていないので、ここはスキップします）")
        print('  確認したいとき（Mac） → python3 setup_check.py "/写真フォルダのパス"')
        print('  確認したいとき（Windows） → py -3 setup_check.py "C:\\写真フォルダのパス"')
        return
    folder = sys.argv[1]
    if not os.path.isdir(folder):
        todo(
            f"指定のフォルダが見つかりません（{folder}）",
            "フォルダのパスをもう一度確認してください（前後の空白や全角に注意）",
        )
        return
    imgs = [f for f in os.listdir(folder)
            if f.lower().endswith(IMAGE_EXTS)]
    if not imgs:
        todo(
            "フォルダの中に画像（.jpg / .png）が見つかりません",
            "写真が入っているフォルダを指定してください",
        )
        return
    ok(f"画像を {len(imgs)} 枚みつけました")

    matching = [f for f in imgs if PHOTO_NAME_RE.search(f)]
    non_matching = [f for f in imgs if not PHOTO_NAME_RE.search(f)]
    if not matching:
        todo(
            "写真はありますが、写真帳に使える名前の画像が見つかりません",
            "ファイル名の最後を 0001S.JPG / 0002F.JPG のようにしてください（半角数字4桁＋SまたはF）",
        )
        return
    ok(f"命名ルールに合う写真を {len(matching)} 枚みつけました")
    if non_matching:
        examples = "、".join(non_matching[:3])
        warn(
            f"命名ルール外の画像が {len(non_matching)} 枚あります（例：{examples}）",
            "今回は写真帳に入りません。必要な写真なら 0001S.JPG の形に直してください",
        )

    # 実際に開けるか試す
    if can_pillow:
        broken = []
        from PIL import Image
        for fn in matching:
            try:
                with Image.open(os.path.join(folder, fn)) as im:
                    im.verify()
            except Exception as e:
                broken.append((fn, e))
        if broken:
            examples = "、".join(f"{fn}（{e}）" for fn, e in broken[:3])
            todo(
                f"開けない画像が {len(broken)} 枚あります（例：{examples}）",
                "写真ファイルが壊れていないか、別の写真として保存し直せるか確認してください",
            )
        else:
            ok("命名ルールに合う画像はすべて開けました")


def summary():
    section("🩺 診断結果まとめ")
    if warn_list:
        print(f"  注意点が {len(warn_list)} 件あります（作成は進められます）：\n")
        for i, (msg, how) in enumerate(warn_list, 1):
            print(f"   {i}. {msg}")
            if how:
                print(f"      → {how}")
        print()
    if not todo_list:
        print("  🎉 すべてOKです！ 写真帳づくりに進めます。")
        print("  次のステップ → build_album_xlsx.py を動かしてください")
    else:
        print(f"  あと {len(todo_list)} か所だけ整えれば準備完了です：\n")
        for i, (msg, how) in enumerate(todo_list, 1):
            print(f"   {i}. {msg}")
            print(f"      → {how}")
        print("\n  直したら、もう一度この診断（setup_check.py）を走らせてください。")
        print("  困ったら、この画面をそのままコピーして相談窓口に送ってくださいね。")
    print()
    return not todo_list


def main():
    print("\n🩺 写真帳作成スキル — 環境ドクターをはじめます")
    print("   （お使いのパソコンが準備OKか、1つずつ確認します）")
    check_python()
    can_openpyxl, can_pillow = check_libraries()
    check_excel_write(can_openpyxl)
    check_photo_folder(can_pillow)
    return summary()


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
