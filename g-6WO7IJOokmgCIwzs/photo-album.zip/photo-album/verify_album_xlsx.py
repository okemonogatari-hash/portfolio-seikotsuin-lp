#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
写真帳Excelの検証スクリプト（Windows/Mac共通）

使い方:
    py -3 verify_album_xlsx.py
    py -3 verify_album_xlsx.py 写真帳_出力.xlsx
    python3 verify_album_xlsx.py 写真帳_出力.xlsx

unzip / grep などOS差のあるコマンドを使わず、Pythonだけで
「画像が実体として埋め込まれているか」「黄色の要確認セルがあるか」を見ます。
"""
import json
import os
import sys
import zipfile


DEFAULT_XLSX = "写真帳_出力.xlsx"
SUMMARY_JSON = "album_check_result.json"


def configure_output():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def find_target():
    if len(sys.argv) >= 2:
        return sys.argv[1]
    if os.path.exists(DEFAULT_XLSX):
        return DEFAULT_XLSX
    candidates = sorted(
        [
            f for f in os.listdir(".")
            if f.startswith("写真帳_出力_") and f.lower().endswith(".xlsx")
        ],
        reverse=True,
    )
    return candidates[0] if candidates else DEFAULT_XLSX


def count_media_files(path):
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
    return [n for n in names if n.startswith("xl/media/image")]


def inspect_yellow_cells(path):
    try:
        import openpyxl
    except ImportError:
        return None, [
            "openpyxlが無いため、黄色セルの中身までは確認できませんでした。"
        ]

    wb = openpyxl.load_workbook(path, data_only=True)
    yellow_values = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                value = "" if cell.value is None else str(cell.value)
                fill = cell.fill
                fg = getattr(fill.fgColor, "rgb", "") or ""
                is_yellow = fg.upper().endswith("FFFF00")
                says_problem = "見つかりません" in value or "開けません" in value
                if is_yellow or says_problem:
                    yellow_values.append({
                        "sheet": ws.title,
                        "cell": cell.coordinate,
                        "value": value,
                    })
    return yellow_values, []


def write_summary(summary):
    with open(SUMMARY_JSON, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)


def main():
    configure_output()
    target = find_target()
    summary = {
        "target": os.path.abspath(target),
        "exists": os.path.exists(target),
        "status": "fail",
        "image_count": 0,
        "yellow_cell_count": None,
        "yellow_cells": [],
        "notes": [],
    }

    print("\n写真帳Excelの検証をはじめます")
    if not os.path.exists(target):
        print(f"NG: Excelファイルが見つかりません: {target}")
        summary["notes"].append("Excelファイルが見つかりません。")
        write_summary(summary)
        return 1

    try:
        media_files = count_media_files(target)
    except zipfile.BadZipFile:
        print(f"NG: Excelファイルとして開けません: {target}")
        summary["notes"].append("Excelファイルとして開けません。")
        write_summary(summary)
        return 1

    summary["image_count"] = len(media_files)
    print(f"OK: Excelファイルがあります: {target}")
    print(f"OK: 埋め込み画像は {len(media_files)} 枚です")

    if not media_files:
        print("NG: 画像がExcel内に埋め込まれていません")
        summary["notes"].append("画像がExcel内に埋め込まれていません。")
        write_summary(summary)
        return 1

    yellow_cells, notes = inspect_yellow_cells(target)
    summary["notes"].extend(notes)
    if yellow_cells is not None:
        summary["yellow_cells"] = yellow_cells
        summary["yellow_cell_count"] = len(yellow_cells)
        if yellow_cells:
            print(f"要確認: 黄色セル/確認セルが {len(yellow_cells)} 個あります")
            for item in yellow_cells[:10]:
                print(f"  - {item['sheet']}!{item['cell']}: {item['value']}")
            summary["status"] = "needs_review"
            write_summary(summary)
            print(f"検証結果を書き出しました: {SUMMARY_JSON}")
            return 2

    summary["status"] = "ok"
    write_summary(summary)
    print("OK: 黄色の要確認セルは見つかりませんでした")
    print(f"検証結果を書き出しました: {SUMMARY_JSON}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
