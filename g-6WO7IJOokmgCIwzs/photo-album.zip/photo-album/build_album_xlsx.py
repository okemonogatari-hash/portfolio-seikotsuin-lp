#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
写真帳作成スキル — 本体（Excel直出力・ローカル完結版）

写真フォルダを読み、お預かりしたエクセルテンプレ（K1903042）と同じ配置ルールで
写真帳のエクセル（.xlsx）を作ります。Google等の外部サービスは使いません。

使い方:
    python3 build_album_xlsx.py                         ← 同梱サンプルで作る
    python3 build_album_xlsx.py "/写真フォルダのパス"   ← 自分の写真で作る
    py -3 build_album_xlsx.py                           ← Windowsの場合

できたエクセルは、Microsoft Excel または Mac標準の Numbers で開けます。
"""
from datetime import datetime
import os
import re
import shutil
import sys
import tempfile

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.drawing.image import Image as XLImage
from PIL import Image as PILImage, ImageOps


def configure_output():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


configure_output()


HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PHOTO_DIR = os.path.join(HERE, "sample")
OUT_PATH = os.path.join(HERE, "写真帳_出力.xlsx")

ROWS_PER_BLOCK = 8          # 1ブロック（写真＋テキスト）の行数
COL_W = {"A": 46, "B": 20, "C": 20, "D": 46}  # 列幅（A/D=写真、B/C=テキスト）
ROW_H_PT = 22               # 写真ブロックの各行の高さ（ポイント）
IMAGE_EXTS = (".jpg", ".jpeg", ".png")
PHOTO_NAME_RE = re.compile(r"(\d{4})([SF])\.(jpe?g|png)$", re.IGNORECASE)


def col_width_to_px(w):
    return int(w * 7 + 5)


def pt_to_px(pt):
    return int(pt * 96 / 72)


# ── 写真を集める（ファイル名末尾「連番＋S/F」で拾う）──
def collect_local_photos(folder):
    photos = []
    ignored_images = []
    for fn in sorted(os.listdir(folder)):
        if not fn.lower().endswith(IMAGE_EXTS):
            continue
        m = PHOTO_NAME_RE.search(fn)
        if not m:
            ignored_images.append(fn)
            continue
        photos.append({
            "filename": fn,
            "local_path": os.path.join(folder, fn),
            "seq": int(m.group(1)),
            "kind": m.group(2).upper(),
        })
    return photos, ignored_images


# ── テキスト欄の縦並びを作る（実物エクセル準拠）──
def build_text_lines(item):
    cat = item.get("category", "")
    if cat == "余白":
        return ["余白"] + [""] * 7
    lines = ["No.", cat]
    if cat == "取付管":
        lines.append(item.get("position", ""))
    elif cat == "異常箇所":
        lines.append(item.get("position", ""))
        sub = item.get("category_sub", "")
        if sub:
            lines.append(sub)
        if item.get("j_no"):
            lines.append(item["j_no"])
        if item.get("meter"):
            lines.append(item["meter"])
    while len(lines) < 8:
        lines.append("")
    return lines[:8]


# ── ページ構成（実物エクセルとの照合で確定・2026-05-02）──
GROUPS = [
    {
        "page_label": "ページ1",
        "sections": [
            {"left": {"category": "余白"},
             "right": {"category": "取付管", "position": "左1", "photo_seq": "0005S"}},
            {"left": {"category": "余白"},
             "right": {"category": "取付管", "position": "左1", "photo_seq": "0004S"}},
        ],
    },
    {
        "page_label": "ページ2",
        "sections": [
            {"left": {"category": "取付管", "position": "左1", "photo_seq": "0006S"},
             "right": {"category": "異常箇所", "position": "No.1", "category_sub": "浸入水b", "j_no": "J1", "meter": "3.67m", "photo_seq": "0002F"}},
            {"left": {"category": "取付管", "position": "左1", "photo_seq": "0003S"},
             "right": {"category": "異常箇所", "position": "No.1", "category_sub": "浸入水b", "j_no": "J1", "meter": "3.67m", "photo_seq": "0001S"}},
        ],
    },
    {
        "page_label": "ページ3",
        "sections": [
            {"left": {"category": "異常箇所", "position": "No.2", "category_sub": "浸入水b", "j_no": "J2", "meter": "6.02m", "photo_seq": "0008F"},
             "right": {"category": "異常箇所", "position": "No.3", "category_sub": "浸入水b", "j_no": "J3", "meter": "8.33m", "photo_seq": "0010F"}},
            {"left": {"category": "異常箇所", "position": "No.2", "category_sub": "浸入水b", "j_no": "J2", "meter": "6.02m", "photo_seq": "0007S"},
             "right": {"category": "異常箇所", "position": "No.3", "category_sub": "浸入水b", "j_no": "J3", "meter": "8.33m", "photo_seq": "0009S"}},
        ],
    },
]


def main():
    folder = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PHOTO_DIR
    if not os.path.isdir(folder):
        print(f"⚠️ 写真フォルダが見つかりません: {folder}")
        print('   使い方（Mac）: python3 build_album_xlsx.py "/写真フォルダのパス"')
        print('   使い方（Windows）: py -3 build_album_xlsx.py "C:\\写真フォルダのパス"')
        sys.exit(1)

    photos, ignored_images = collect_local_photos(folder)
    if not photos:
        print("⚠️ 写真帳に使える名前の写真が見つかりません。")
        print("   ファイル名の最後を 0001S.JPG / 0002F.JPG のようにしてください。")
        print("   （半角数字4桁 + S または F。jpg / jpeg / png に対応）")
        if ignored_images:
            print(f"   命名ルール外の画像例: {', '.join(ignored_images[:5])}")
        sys.exit(1)

    photo_map = {}
    duplicates = []
    for p in photos:
        key = f"{p['seq']:04d}{p['kind']}"
        if key in photo_map:
            duplicates.append((key, os.path.basename(photo_map[key]), p["filename"]))
        photo_map[key] = p["local_path"]

    print(f"📷 写真 {len(photos)} 枚を読みました（取付管系S={sum(1 for p in photos if p['kind']=='S')} / 異常系F={sum(1 for p in photos if p['kind']=='F')}）")
    if ignored_images:
        print(f"⚠️ 命名ルール外の画像は今回は使いません: {', '.join(ignored_images[:5])}")
    if duplicates:
        for key, old_name, new_name in duplicates[:5]:
            print(f"⚠️ 同じ番号の写真があります（{key}: {old_name} / {new_name}）。後から読んだ方を使います。")

    wb = Workbook()
    ws = wb.active
    ws.title = "写真帳"
    for c, w in COL_W.items():
        ws.column_dimensions[c].width = w

    thin = Side(style="thin")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    yellow = PatternFill("solid", fgColor="FFFF00")
    label_fill = PatternFill("solid", fgColor="D9EBFF")

    tmpdir = tempfile.mkdtemp()
    photo_px_w = col_width_to_px(COL_W["A"])
    block_px_h = pt_to_px(ROW_H_PT) * ROWS_PER_BLOCK

    missing = []
    broken = []

    def place_photo(seq, col, top_row):
        if not seq:
            return
        cell = f"{col}{top_row}"
        path = photo_map.get(seq)
        if not path:
            ws[cell] = f"(写真 {seq} が\n見つかりません)"
            ws[cell].fill = yellow
            ws[cell].alignment = center
            missing.append(seq)
            return
        try:
            with PILImage.open(path) as opened:
                im = ImageOps.exif_transpose(opened)
                im.thumbnail((photo_px_w, block_px_h))
                tmp = os.path.join(tmpdir, f"{seq}_{col}.png")
                im.convert("RGB").save(tmp)
            ws.add_image(XLImage(tmp), cell)
        except Exception as e:
            ws[cell] = f"(写真 {seq} を\n開けません)"
            ws[cell].fill = yellow
            ws[cell].alignment = center
            broken.append((seq, os.path.basename(path), e))

    def place_text(lines, col, top_row):
        for i, line in enumerate(lines):
            cell = f"{col}{top_row + i}"
            ws[cell] = line
            ws[cell].alignment = center
            ws[cell].border = border

    try:
        row = 1
        ws.merge_cells(f"A{row}:D{row}")
        ws[f"A{row}"] = "【写真帳】自動生成サンプル（K1903042）"
        ws[f"A{row}"].font = Font(bold=True, size=14)
        ws[f"A{row}"].alignment = center
        ws.row_dimensions[row].height = 30
        row += 2

        for g in GROUPS:
            ws.merge_cells(f"A{row}:D{row}")
            ws[f"A{row}"] = f"━━ {g['page_label']} ━━"
            ws[f"A{row}"].font = Font(bold=True)
            ws[f"A{row}"].alignment = center
            ws[f"A{row}"].fill = label_fill
            row += 1

            for sec in g["sections"]:
                top = row
                for r in range(top, top + ROWS_PER_BLOCK):
                    ws.row_dimensions[r].height = ROW_H_PT
                place_photo(sec["left"].get("photo_seq"), "A", top)
                place_text(build_text_lines(sec["left"]), "B", top)
                place_text(build_text_lines(sec["right"]), "C", top)
                place_photo(sec["right"].get("photo_seq"), "D", top)
                row += ROWS_PER_BLOCK + 1  # ブロック間スペーサー1行
            row += 1  # ページ間スペーサー

        saved_path = OUT_PATH
        try:
            wb.save(saved_path)
        except PermissionError:
            base, ext = os.path.splitext(OUT_PATH)
            saved_path = f"{base}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext}"
            wb.save(saved_path)
            print("⚠️ いつもの出力ファイルに保存できませんでした。")
            print("   Excelで開いたままの可能性があるので、別名で保存しました。")
        except Exception as e:
            print(f"⚠️ エクセルの保存に失敗しました: {e}")
            print("   保存先の権限・空き容量・ファイル名を確認してください。")
            sys.exit(1)

        print(f"✅ 写真帳を作成しました → {saved_path}")
        if missing:
            print(f"⚠️ 写真が見つからなかった枠が {len(missing)} 個あります（黄色セルで表示）: {missing}")
        if broken:
            examples = ", ".join(f"{seq}:{name}" for seq, name, _ in broken[:5])
            print(f"⚠️ 開けなかった写真が {len(broken)} 枚あります（黄色セルで表示）: {examples}")
        print("   Microsoft Excel または Mac標準の Numbers で開いてください。")
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
