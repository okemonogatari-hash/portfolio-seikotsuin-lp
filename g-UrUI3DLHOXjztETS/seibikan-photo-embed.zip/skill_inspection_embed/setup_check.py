#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🩺 管きょ点検記録表 写真埋め込みスキル — 環境ドクター

このスクリプトは「写真埋め込み本体」を動かす前に、
お使いのパソコンが準備OKかをやさしく1つずつ確認します。

使い方:
    python3 setup_check.py   ← Mac
    py -3 setup_check.py     ← Windows
"""
import sys
import os
import tempfile
from pathlib import Path

todo_list = []


def ok(msg): print(f"  ✅ {msg}")
def todo(msg, how):
    todo_list.append((msg, how))
    print(f"  ⚠️ {msg}\n      → 直し方：{how}")
def section(t):
    print("\n" + "─" * 52)
    print(f"  {t}")
    print("─" * 52)


def install_cmd(pip_name):
    exe = sys.executable or "python"
    return f"{exe} -m pip install {pip_name}"


def check_python():
    section("① Python が使えるか")
    v = sys.version_info
    if v.major == 3 and v.minor >= 8:
        ok(f"Python {v.major}.{v.minor} が入っています")
    else:
        todo(
            f"Python {v.major}.{v.minor} は古めです",
            "Python 3.10 以上を入れると安心です（https://www.python.org）",
        )


def check_library(import_name, pip_name, nice):
    try:
        __import__(import_name)
        ok(f"{nice} が入っています")
        return True
    except ImportError:
        todo(
            f"{nice} がまだ入っていません",
            f"次の1行を実行 → {install_cmd(pip_name)}",
        )
        return False


def check_libraries():
    section("② 必要な部品（ライブラリ）がそろっているか")
    a = check_library("openpyxl", "openpyxl", "openpyxl（エクセルを作る部品）")
    b = check_library("PIL", "Pillow", "Pillow（画像をあつかう部品）")
    return a and b


def check_template():
    section("③ テンプレ（管きょ点検記録表）があるか")
    here = Path(__file__).resolve().parent
    tpl = here / "template_管きょ点検記録表.xlsx"
    if tpl.exists():
        ok(f"テンプレが見つかりました（{tpl.stat().st_size:,} bytes）")
        return True
    else:
        todo(
            "テンプレファイルが見つかりません",
            "ZIPの中身が欠けています。もう一度ZIPを展開し直してください",
        )
        return False


def check_xlsx_write(can_use_lib):
    section("④ エクセル(.xlsx)を作って読めるか（おためし1枚）")
    if not can_use_lib:
        todo(
            "openpyxl が無いので、まだエクセルは作れません",
            "②を直してから、もう一度この診断を走らせてください",
        )
        return
    try:
        import openpyxl
        wb = openpyxl.Workbook()
        wb.active["A1"] = "テスト"
        fd, tmp = tempfile.mkstemp(prefix="_test_", suffix=".xlsx")
        os.close(fd)
        try:
            wb.save(tmp)
            openpyxl.load_workbook(tmp)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        ok("エクセルを作って読むテストに成功しました")
    except Exception as e:
        todo(
            f"エクセルの作成/読み込みに失敗しました（{e}）",
            "パソコンの空き容量・書き込み権限を確認してください",
        )


def check_photos_dir():
    section("⑤ 写真フォルダ photos_here/ の中身")
    here = Path(__file__).resolve().parent
    photos = here / "photos_here"
    if not photos.exists():
        photos.mkdir(parents=True, exist_ok=True)
        ok("photos_here/ フォルダを作りました（中身は空）")
        print("      → ここにマンホール番号フォルダ（例：056/）を入れてください")
        return
    subs = [p for p in photos.iterdir() if p.is_dir() and not p.name.startswith(("_", "."))]
    if not subs:
        ok(f"photos_here/ は準備OKです（まだフォルダなし）")
        print("      → マンホール番号フォルダ（例：056/）をここに入れてください")
        return
    total = 0
    for s in subs[:5]:
        photos_in = sum(1 for p in s.iterdir()
                        if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
        total += photos_in
        ok(f"photos_here/{s.name}/ → 写真 {photos_in} 枚")
    if len(subs) > 5:
        print(f"      ...（他 {len(subs)-5} 件）")
    ok(f"合計 {len(subs)} フォルダ・写真累計 {total} 枚")


def summary():
    section("🩺 診断結果まとめ")
    if not todo_list:
        print("  🎉 すべてOKです！ 写真埋め込みに進めます。")
        print("  次のステップ → Claude Code に『写真をExcelに入れて』と言うか、")
        print("             py -3 embed_photos.py を動かしてください")
    else:
        print(f"  あと {len(todo_list)} か所だけ整えれば準備完了です：\n")
        for i, (msg, how) in enumerate(todo_list, 1):
            print(f"   {i}. {msg}")
            print(f"      → {how}")
        print("\n  直したら、もう一度この診断を走らせてください。")
    print()
    return not todo_list


def main():
    print("\n🩺 管きょ点検記録表 写真埋め込みスキル — 環境ドクター")
    check_python()
    can = check_libraries()
    check_template()
    check_xlsx_write(can)
    check_photos_dir()
    return summary()


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
