#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
📸 管きょ点検記録表 写真埋め込みスキル

photos_here/{マンホール番号}/ フォルダの現場写真を、
管きょ点検記録表（原本フォーマット）の写真欄に自動配置して、
output_excel/ に xlsx を出力します。

使い方:
    py -3 embed_photos.py             ← photos_here/ 内の全マンホールを処理
    py -3 embed_photos.py 056         ← マンホール 056 だけ処理
"""
import sys
import shutil
from pathlib import Path
from datetime import date

try:
    from PIL import Image as PILImage
    from openpyxl import load_workbook
    from openpyxl.drawing.image import Image as XLImage
except ImportError as e:
    print(f"❌ 必要なライブラリが入っていません: {e}")
    print("   → setup_check.py を先に走らせてください")
    sys.exit(1)


HERE = Path(__file__).resolve().parent
PHOTOS_DIR = HERE / "photos_here"
OUTPUT_DIR = HERE / "output_excel"
TEMPLATE = HERE / "template_管きょ点検記録表.xlsx"
TMP_DIR = OUTPUT_DIR / "_resized"

# 写真欄マージセル（原本フォーマット）
PHOTO_SLOTS = [
    # (anchor, max_w_px, max_h_px, caption,                         label_cell, label_text)
    ("B29", 729, 294, "管きょ状況写真",                              "K29", "写真No. 1"),
    ("B42", 729, 375, "マンホール蓋状況写真",                         "B40", "写真No. 2"),
    ("J42", 663, 375, "マンホール蓋開口時 内部写真",                   None,  None),
]

IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".JPG", ".JPEG", ".PNG")


def resize_to_fit(src: Path, dst: Path, max_w: int, max_h: int) -> tuple[int, int]:
    """アスペクト比維持で max_w × max_h に収まる最大サイズ"""
    img = PILImage.open(src).convert("RGB")
    w, h = img.size
    ratio = min(max_w / w, max_h / h)
    new_w, new_h = int(w * ratio), int(h * ratio)
    img = img.resize((new_w, new_h), PILImage.LANCZOS)
    img.save(dst, "PNG", optimize=True)
    return new_w, new_h


def process_manhole(folder: Path) -> Path | None:
    """1つのマンホールフォルダを処理 → 出力xlsxパス"""
    manhole_no = folder.name
    photos = sorted([p for p in folder.iterdir() if p.suffix in IMAGE_EXTS])
    if not photos:
        print(f"  ⚠️ {manhole_no}/ に写真がありません（スキップ）")
        return None

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    TMP_DIR.mkdir(parents=True, exist_ok=True)

    out_name = f"点検記録表_{manhole_no}_{date.today().isoformat()}.xlsx"
    out_path = OUTPUT_DIR / out_name
    shutil.copy(TEMPLATE, out_path)

    wb = load_workbook(out_path)
    ws = wb["点検記録表"]
    ws["F4"].value = f"マンホール番号: {manhole_no}"

    placed = 0
    for (anchor, max_w, max_h, caption, label_cell, label_text), photo in zip(PHOTO_SLOTS, photos):
        tmp_png = TMP_DIR / f"{manhole_no}_{anchor}.png"
        nw, nh = resize_to_fit(photo, tmp_png, max_w - 8, max_h - 8)
        ws.add_image(XLImage(str(tmp_png)), anchor)
        if label_cell and label_text:
            ws[label_cell].value = f"{label_text}: {photo.name}"
        placed += 1
        print(f"  📸 {anchor}: {caption} ← {photo.name} ({nw}×{nh}px)")

    wb.save(out_path)
    print(f"  ✅ 出力: {out_path.name}")
    return out_path


def main():
    if not TEMPLATE.exists():
        print(f"❌ テンプレが見つかりません: {TEMPLATE}")
        sys.exit(1)

    if not PHOTOS_DIR.exists():
        print(f"❌ 写真フォルダがありません: {PHOTOS_DIR}")
        print(f"   photos_here/ にマンホール番号フォルダ（例：056/）を入れてください")
        sys.exit(1)

    if len(sys.argv) >= 2:
        # 個別指定
        manhole = sys.argv[1]
        folder = PHOTOS_DIR / manhole
        if not folder.is_dir():
            print(f"❌ photos_here/{manhole}/ が見つかりません")
            sys.exit(1)
        targets = [folder]
    else:
        # 全マンホール
        targets = sorted([p for p in PHOTOS_DIR.iterdir()
                          if p.is_dir() and not p.name.startswith(("_", "."))])
        if not targets:
            print(f"⚠️ photos_here/ に処理対象フォルダが見つかりません")
            print(f"   例：photos_here/056/  photos_here/057/  ...")
            sys.exit(0)

    print(f"\n📂 {len(targets)} 件のマンホールを処理します\n")
    success = 0
    for folder in targets:
        print(f"━━━ {folder.name} ━━━")
        if process_manhole(folder):
            success += 1
        print()

    print(f"🎉 完了: {success}/{len(targets)} 件\n")
    print(f"出力先: {OUTPUT_DIR}/")
    print(f"  → Excelで開いて確認してください")


if __name__ == "__main__":
    main()
